# DASHBOARD SMK GUNSANAD

Portal Digital Rasmi SMK Gunsanad, Keningau.

## Cara Upload ke GitHub Pages

1. Log masuk ke [GitHub](https://github.com)
2. Buat repository baru — contohnya `smkgunsanad-portal`
3. Upload semua fail dari folder ini (`index.html` dan folder `images/`)
4. Pergi ke **Settings → Pages**
5. Di bahagian **Source**, pilih:
   - Branch: `main`
   - Folder: `/ (root)`
6. Klik **Save** dan tunggu beberapa saat.

Portal anda akan tersedia di:
```
https://<username>.github.io/smkgunsanad-portal/
```
